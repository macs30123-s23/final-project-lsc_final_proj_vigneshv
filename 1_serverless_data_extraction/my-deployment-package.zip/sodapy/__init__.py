from sodapy.socrata import Socrata
from sodapy import version

__all__ = [
    "Socrata",
]
__version__ = version.__version__
